"use client"

import { useState } from "react"
import { X } from "lucide-react"
import { LoginForm } from "./login-form"
import { SignupForm } from "./signup-form"
import { ForgotPasswordForm } from "./forgot-password-form"
import { SuccessPopup } from "./success-popup"

interface AuthModalProps {
  isOpen: boolean
  onClose: () => void
  initialMode?: "login" | "signup"
}

export function AuthModal({ isOpen, onClose, initialMode = "login" }: AuthModalProps) {
  const [mode, setMode] = useState<"login" | "signup" | "forgot">(initialMode)
  const [showSuccess, setShowSuccess] = useState(false)
  const [successData, setSuccessData] = useState({ success: false, message: "" })

  if (!isOpen) return null

  const handleToggleMode = () => {
    setMode(mode === "login" ? "signup" : "login")
  }

  const handleForgotPassword = () => {
    setMode("forgot")
  }

  const handleBack = () => {
    setMode("login")
  }

  const handleShowSuccess = (success: boolean, message: string) => {
    setSuccessData({ success, message })
    setShowSuccess(true)
  }

  const handleCloseSuccess = () => {
    setShowSuccess(false)
  }

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center">
        <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={onClose} />
        <div className="relative z-10 w-full max-w-md mx-4">
          <button
            onClick={onClose}
            className="absolute -top-4 -right-4 w-8 h-8 bg-slate-800 rounded-full flex items-center justify-center text-slate-400 hover:text-white hover:bg-slate-700 transition-colors z-10"
          >
            <X className="w-4 h-4" />
          </button>

          {mode === "login" && (
            <LoginForm
              onToggleMode={handleToggleMode}
              onForgotPassword={handleForgotPassword}
              onClose={onClose}
              onShowSuccess={handleShowSuccess}
            />
          )}
          {mode === "signup" && (
            <SignupForm onToggleMode={handleToggleMode} onClose={onClose} onShowSuccess={handleShowSuccess} />
          )}
          {mode === "forgot" && <ForgotPasswordForm onBack={handleBack} onShowSuccess={handleShowSuccess} />}
        </div>
      </div>

      <SuccessPopup
        isOpen={showSuccess}
        success={successData.success}
        message={successData.message}
        onClose={handleCloseSuccess}
      />
    </>
  )
}
