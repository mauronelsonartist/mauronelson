"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Mail, ArrowLeft, Loader2 } from "lucide-react"
import { useAuth } from "./auth-context"

interface ForgotPasswordFormProps {
  onBack: () => void
  onShowSuccess: (success: boolean, message: string) => void
}

export function ForgotPasswordForm({ onBack, onShowSuccess }: ForgotPasswordFormProps) {
  const [email, setEmail] = useState("")
  const [errors, setErrors] = useState<{ email?: string }>({})
  const [isLoading, setIsLoading] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)
  const { resetPassword } = useAuth()

  const validateForm = () => {
    const newErrors: { email?: string } = {}

    if (!email) {
      newErrors.email = "Email is required"
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      newErrors.email = "Please enter a valid email"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!validateForm()) return

    setIsLoading(true)

    const result = await resetPassword(email)
    onShowSuccess(result.success, result.message)

    if (result.success) {
      setIsSubmitted(true)
    }

    setIsLoading(false)
  }

  if (isSubmitted) {
    return (
      <Card className="w-full max-w-md bg-slate-800 border-slate-700">
        <CardContent className="p-8 text-center">
          <div className="mb-6">
            <div className="w-16 h-16 bg-green-900/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <Mail className="w-8 h-8 text-green-400" />
            </div>
            <h2 className="text-3xl font-light text-white mb-2">Check Your Email</h2>
            <p className="text-slate-300 text-lg">
              We've sent password reset instructions to <strong>{email}</strong>
            </p>
          </div>
          <Button
            onClick={onBack}
            variant="outline"
            className="border-slate-600 hover:bg-slate-700 bg-transparent text-lg h-14"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Sign In
          </Button>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="w-full max-w-md bg-slate-800 border-slate-700">
      <CardHeader>
        <CardTitle className="text-3xl font-light text-center text-white">Reset Password</CardTitle>
        <p className="text-slate-400 text-center text-lg">
          Enter your email and we'll send you instructions to reset your password
        </p>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <label htmlFor="email" className="text-lg font-medium text-slate-300">
              Email
            </label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-400" />
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="pl-10 bg-slate-700 border-slate-600 text-white text-lg h-14"
                placeholder="Enter your email"
              />
            </div>
            {errors.email && <p className="text-red-400 text-lg">{errors.email}</p>}
          </div>

          <Button
            type="submit"
            disabled={isLoading}
            className="w-full bg-amber-600 hover:bg-amber-700 text-white text-lg h-14"
          >
            {isLoading ? (
              <>
                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                Sending...
              </>
            ) : (
              "Send Reset Instructions"
            )}
          </Button>

          <Button
            type="button"
            onClick={onBack}
            variant="outline"
            className="w-full border-slate-600 hover:bg-slate-700 bg-transparent text-lg h-14"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Sign In
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
