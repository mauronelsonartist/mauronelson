"use client"

import { useEffect } from "react"
import { CheckCircle, XCircle } from "lucide-react"

interface SuccessPopupProps {
  isOpen: boolean
  success: boolean
  message: string
  onClose: () => void
}

export function SuccessPopup({ isOpen, success, message, onClose }: SuccessPopupProps) {
  useEffect(() => {
    if (isOpen) {
      const timer = setTimeout(() => {
        onClose()
      }, 3000)
      return () => clearTimeout(timer)
    }
  }, [isOpen, onClose])

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center">
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" />
      <div
        className={`relative z-10 bg-slate-800 border rounded-lg p-8 mx-4 max-w-md w-full transform transition-all duration-300 ${
          isOpen ? "scale-100 opacity-100" : "scale-95 opacity-0"
        } ${success ? "border-green-600" : "border-red-600"}`}
      >
        <div className="text-center">
          <div className="mb-4">
            {success ? (
              <CheckCircle className="w-16 h-16 text-green-400 mx-auto" />
            ) : (
              <XCircle className="w-16 h-16 text-red-400 mx-auto" />
            )}
          </div>
          <h3 className={`text-2xl font-semibold mb-3 ${success ? "text-green-400" : "text-red-400"}`}>
            {success ? "Success!" : "Error"}
          </h3>
          <p className="text-slate-300 text-lg leading-relaxed">{message}</p>
          <div className="mt-6">
            <div className="w-full bg-slate-700 rounded-full h-1">
              <div
                className={`h-1 rounded-full transition-all duration-3000 ease-linear ${
                  success ? "bg-green-400" : "bg-red-400"
                }`}
                style={{ width: "100%", animation: "shrink 3s linear" }}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
