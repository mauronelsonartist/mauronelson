"use client"

import type React from "react"

import { createContext, useContext, useState, useEffect } from "react"

interface User {
  id: string
  name: string
  email: string
  avatar?: string
}

interface AuthContextType {
  user: User | null
  login: (email: string, password: string) => Promise<{ success: boolean; message: string }>
  signup: (name: string, email: string, password: string) => Promise<{ success: boolean; message: string }>
  logout: () => void
  resetPassword: (email: string) => Promise<{ success: boolean; message: string }>
  loginWithGoogle: () => Promise<{ success: boolean; message: string }>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)

  useEffect(() => {
    // Check for existing session
    const savedUser = localStorage.getItem("user")
    if (savedUser) {
      setUser(JSON.parse(savedUser))
    }
  }, [])

  const login = async (email: string, password: string): Promise<{ success: boolean; message: string }> => {
    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Demo credentials
      if (email === "demo@example.com" && password === "password") {
        const demoUser = {
          id: "demo-user",
          name: "Demo User",
          email: "demo@example.com",
          avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=32&h=32&fit=crop&crop=face",
        }
        setUser(demoUser)
        localStorage.setItem("user", JSON.stringify(demoUser))
        return { success: true, message: "Welcome back!" }
      }

      return { success: false, message: "Invalid email or password. Try demo@example.com / password" }
    } catch (error) {
      return { success: false, message: "Login failed. Please try again." }
    }
  }

  const signup = async (
    name: string,
    email: string,
    password: string,
  ): Promise<{ success: boolean; message: string }> => {
    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // Simulate validation
      if (email.includes("test@")) {
        return { success: false, message: "This email is already registered." }
      }

      const newUser = {
        id: `user-${Date.now()}`,
        name,
        email,
        avatar: `https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=32&h=32&fit=crop&crop=face`,
      }

      setUser(newUser)
      localStorage.setItem("user", JSON.stringify(newUser))
      return { success: true, message: `Welcome to the community, ${name}!` }
    } catch (error) {
      return { success: false, message: "Account creation failed. Please try again." }
    }
  }

  const loginWithGoogle = async (): Promise<{ success: boolean; message: string }> => {
    try {
      // Simulate Google OAuth
      await new Promise((resolve) => setTimeout(resolve, 1000))

      const googleUser = {
        id: "google-user",
        name: "Google User",
        email: "user@gmail.com",
        avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=32&h=32&fit=crop&crop=face",
      }

      setUser(googleUser)
      localStorage.setItem("user", JSON.stringify(googleUser))
      return { success: true, message: "Successfully signed in with Google!" }
    } catch (error) {
      return { success: false, message: "Google sign-in failed. Please try again." }
    }
  }

  const resetPassword = async (email: string): Promise<{ success: boolean; message: string }> => {
    try {
      // Simulate sending email
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Simulate email service
      console.log(`Password reset email sent to: ${email}`)

      return {
        success: true,
        message: `Password reset instructions have been sent to ${email}. Please check your inbox and spam folder.`,
      }
    } catch (error) {
      return { success: false, message: "Failed to send reset email. Please try again." }
    }
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem("user")
  }

  return (
    <AuthContext.Provider value={{ user, login, signup, logout, resetPassword, loginWithGoogle }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
